<?php

session_start();
$servidor = "localhost";
$usuario = "root";
$senha = "";
$dbname = "roleta";

//Criar a conexao
$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);

if (!$conn) {
    die("Falha na conexao: " . mysqli_connect_error());
} else {
    //echo "Conexao realizada com sucesso";
}
$cpf = mysqli_real_escape_string($_POST['cpf']);
$query = "SELECT * FROM usuarios WHERE cpf = '$cpf' LIMIT 1";
$resultado = $conn->query($result_usuario);
$resultado = mysqli_fetch_assoc($resultado_usuario);
if ($resultado->num_rows > 0) {
  alert("Você já participou da promoção");
    
}else{
        
        $result_premios = "SELECT * FROM premios";
        $resultado_premios = mysqli_query($conn, $result_usuarios);
        echo $resultado_premios;
        $numero_sorteado = rand(1, 100);
   if ($numero_sorteado >= 1 && $numero_sorteado <= 5){
       echo "Parabéns você ganhou premio 1";
      
   }
   elseif ($numero_sorteado > 6 && $numero_sorteado <= 10){
   echo "Parabéns você ganhou premio 2";
   }
   elseif ($numero_sorteado > 11 && $numero_sorteado <= 30)
       echo "Parabéns você ganhou premio 3";
   elseif ($numero_sorteado > 31 && $numero_sorteado <= 50)
       echo "Parabéns você ganhou premio 4";
   elseif ($numero_sorteado > 51 && $numero_sorteado <= 100)
       echo "Parabéns você ganhou premio 5";
   elseif ($numero_sorteado > 51 && $numero_sorteado <= 100)
       echo "Parabéns você ganhou premio 6";
   elseif ($numero_sorteado > 51 && $numero_sorteado <= 100)
       echo "Parabéns você ganhou premio 7";
   else
       echo "Usuario já girou a roleta";
}   
?>

 if ($numero_sorteado >= 1 && $numero_sorteado <= 5){
           $premio = 1;
           $result_usuario = "INSERT INTO usuarios(nome, cpf, email, telefone, cep, endereco, bairro, cidade, estado, premio) VALUES ('$nome_usuario','$cpf_usuario','$email_usuario','$telefone_usuario','$cep_usuario','$endereco_usuario','$bairro_usuario','$cidade_usuario','$estado_usuario',$premio)";
           $resultado_usuario = mysqli_query($conn, $result_usuario);
           echo "Parabéns você ganhou premio 1";        
           
       }
       elseif ($numero_sorteado > 6 && $numero_sorteado <= 10){
           $premio = 2;
           $result_usuario = "INSERT INTO usuarios(nome, cpf, email, telefone, cep, endereco, bairro, cidade, estado, premio) VALUES ('$nome_usuario','$cpf_usuario','$email_usuario','$telefone_usuario','$cep_usuario','$endereco_usuario','$bairro_usuario','$cidade_usuario','$estado_usuario',$premio)";
           $resultado_usuario = mysqli_query($conn, $result_usuario);
           echo "Parabéns você ganhou premio 2";

       }
       elseif ($numero_sorteado > 11 && $numero_sorteado <= 30){
           $premio = 3;
           $result_usuario = "INSERT INTO usuarios(nome, cpf, email, telefone, cep, endereco, bairro, cidade, estado, premio) VALUES ('$nome_usuario','$cpf_usuario','$email_usuario','$telefone_usuario','$cep_usuario','$endereco_usuario','$bairro_usuario','$cidade_usuario','$estado_usuario',$premio)";
           $resultado_usuario = mysqli_query($conn, $result_usuario);
           echo "Parabéns você ganhou premio 3";

       }
       elseif ($numero_sorteado > 31 && $numero_sorteado <= 50){
           $premio = 4;
           $result_usuario = "INSERT INTO usuarios(nome, cpf, email, telefone, cep, endereco, bairro, cidade, estado, premio) VALUES ('$nome_usuario','$cpf_usuario','$email_usuario','$telefone_usuario','$cep_usuario','$endereco_usuario','$bairro_usuario','$cidade_usuario','$estado_usuario',$premio)";
           $resultado_usuario = mysqli_query($conn, $result_usuario);
           echo "Parabéns você ganhou premio 4";

       }
       elseif ($numero_sorteado > 51 && $numero_sorteado <= 100){
           $premio = 5;
           $result_usuario = "INSERT INTO usuarios(nome, cpf, email, telefone, cep, endereco, bairro, cidade, estado, premio) VALUES ('$nome_usuario','$cpf_usuario','$email_usuario','$telefone_usuario','$cep_usuario','$endereco_usuario','$bairro_usuario','$cidade_usuario','$estado_usuario',$premio)";
           $resultado_usuario = mysqli_query($conn, $result_usuario);
           echo "Parabéns você ganhou premio 5";

       }
       elseif ($numero_sorteado > 51 && $numero_sorteado <= 100){
           $premio = 6;
           $result_usuario = "INSERT INTO usuarios(nome, cpf, email, telefone, cep, endereco, bairro, cidade, estado, premio) VALUES ('$nome_usuario','$cpf_usuario','$email_usuario','$telefone_usuario','$cep_usuario','$endereco_usuario','$bairro_usuario','$cidade_usuario','$estado_usuario',$premio)";
           $resultado_usuario = mysqli_query($conn, $result_usuario);
           echo "Parabéns você ganhou premio 6";

       }
       elseif ($numero_sorteado > 51 && $numero_sorteado <= 100){
           $premio = 7;
           $result_usuario = "INSERT INTO usuarios(nome, cpf, email, telefone, cep, endereco, bairro, cidade, estado, premio) VALUES ('$nome_usuario','$cpf_usuario','$email_usuario','$telefone_usuario','$cep_usuario','$endereco_usuario','$bairro_usuario','$cidade_usuario','$estado_usuario',$premio)";
           $resultado_usuario = mysqli_query($conn, $result_usuario);
           echo "Parabéns você ganhou premio 7";
         

   }
}   
<?php

include_once("conexao.php");

echo"<pre>";
print_r($_POST);
echo"</pre>";

if ($_POST['botao'] == "contratou") {
    $sql = "UPDATE usuarios SET status = 'contratou' , responsavel_status = '" . $_POST['nomeresponsavel'] . "' WHERE ID = " . $_POST['id_cliente'];
    echo $sql;
    if (mysqli_query($conn, $sql)) {
        echo "Atualizamos com sucesso";
        header('Location: ./index1.php');

    } else {
        echo "Deu merda: " . mysqli_error($conn);
    }
} elseif ($_POST['botao'] == "inviabilidadetec") {
    $sql = "UPDATE usuarios SET status = 'Inviavel Tecnicamente' , responsavel_status = '" . $_POST['nomeresponsavel'] . "' WHERE ID = " . $_POST['id_cliente'];
    echo $sql;
    if (mysqli_query($conn, $sql)) {
        echo "Atualizamos com sucesso";
        header('Location: ./index1.php');

    } else {
        echo "Deu merda: " . mysqli_error($conn);
    }
} elseif ($_POST['botao'] == "inviavelcani") {
    $sql = "UPDATE usuarios SET status = 'Inviavel Cani' , responsavel_status = '" . $_POST['nomeresponsavel'] . "' WHERE ID = " . $_POST['id_cliente'];
    echo $sql;
    if (mysqli_query($conn, $sql)) {
        echo "Atualizamos com sucesso";
        header('Location: ./index1.php');

    } else {
        echo "Deu merda: " . mysqli_error($conn);
    }
}
?>
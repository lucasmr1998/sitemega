<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Rolega Digital - Vetorial Internet</title>

        <!-- css -->
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <link href="css/nivo-lightbox.css" rel="stylesheet" />
        <link href="css/nivo-lightbox-theme/default/default.css" rel="stylesheet" type="text/css" />
        <link href="css/animate.css" rel="stylesheet" />
        <link href="css/style.css" rel="stylesheet">

        <!-- template skin -->
        <link id="t-colors" href="color/default.css" rel="stylesheet">

        <script src="js/jquery.min.js"></script>
        <!-- =======================================================
          Theme Name: Appland
          Theme URL: https://bootstrapmade.com/free-bootstrap-app-landing-page-template/
          Author: BootstrapMade
          Author URL: https://bootstrapmade.com
        ======================================================= -->
    </head>

    <body id="page-top" data-spy="scroll" data-target=".navbar-custom">

        <?php
        //se a sessao nao foi iniciada "setada"
        if (!isset($_SESSION)) {
            session_start();
        }
        echo "<pre>";
        print_r($_SESSION);
        echo "</pre>";
        ?>


        <div id="wrapper">

            <!-- Section: intro -->
            <section id="intro" class="intro">
                <div class="intro-content">
                    <div class="container">

                        <div class="row">
                            <div class="col-sm-6 col-md-6 col-lg-6">
                                <div class="wow fadeInDown" data-wow-offset="0" data-wow-delay="0.1s">

                                    <img id="roleta00" src="images/roleta00.png" class="img-responsive">
                                    <img id="roleta01" src="images/roleta01.png" class="img-responsive" style="display:none">
                                    <img id="roleta02" src="images/roleta02.png" class="img-responsive" style="display:none">
                                    <img id="roleta03" src="images/roleta03.png" class="img-responsive" style="display:none">
                                    <img id="roleta04" src="images/roleta04.png" class="img-responsive" style="display:none">
                                    <img id="roleta05" src="images/roleta05.png" class="img-responsive" style="display:none">
                                    <img id="roleta06" src="images/roleta06.png" class="img-responsive" style="display:none">
                                    <img id="roleta07" src="images/roleta07.png" class="img-responsive" style="display:none">
                                    <img id="roleta08" src="images/roleta08.png" class="img-responsive" style="display:none">
                                    <img id="roleta09" src="images/roleta09.png" class="img-responsive" style="display:none">
                                    <img id="roleta10" src="images/roleta10.png" class="img-responsive" style="display:none">
                                    <img id="roleta11" src="images/roleta11.png" class="img-responsive" style="display:none">
                                    <img id="roleta12" src="images/roleta12.png" class="img-responsive" style="display:none">


                                </div>
                            </div>
                            <?php
                            //se o clieten nao tem premio e nem deu erro
                            if (!isset($_SESSION['premio']) && !isset($_SESSION['erro'])) {
                                echo'<div class="col-sm-6 col-md-6 col-lg-6 slogan">
                                <div class="wow fadeInUp" data-wow-duration="2s" data-wow-delay="0.2s">
                                    <form action="../../roleta/admin/cadastrar.php" method="post">
                                        <h2>Participe da Promoção da Vetorial! Realize seu cadastro.</h2>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="nome">Nome:</label>
                                                    <input type="text" class="form-control" id="nome" name="nome" required>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="telefone">Telefone:</label>
                                                    <input type="text" class="form-control" id="telefone" name="telefone" required>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="email">Email:</label>
                                                    <input type="email" class="form-control" id="email" name="email" required>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="cpf">CPF:</label>
                                                    <input type="text" class="form-control" id="cpf" name="cpf" required>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="cep">CEP:</label>
                                                    <input type="text" class="form-control" id="cep" name="cep" onchange="completa_endereco()">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="cidade">Cidade:</label>
                                                    <input type="text" class="form-control" id="cidade" name="cidade" required>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="estado">Estado:</label>
                                                    <input type="text" class="form-control" id="estado" name="estado" required>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-5">
                                                <div class="form-group">
                                                    <label for="rua">Rua:</label>
                                                    <input type="text" class="form-control" id="rua" name="rua" required>
                                                </div>
                                            </div>
                                            <div class="col-md-2">
                                                <div class="form-group">
                                                    <label for="numero">Nº:</label>
                                                    <input type="text" class="form-control" id="numero" name="numero" required>
                                                </div>
                                            </div>                                          
                                            <div class="col-md-5">
                                                <div class="form-group">
                                                    <label for="bairro">Bairro:</label>
                                                    <input type="text" class="form-control" id="bairro" name="bairro" required>
                                                </div>
                                            </div>
                                        </div>
                                        <input type="hidden" name="canal" value="site">
                                        <button type="submit" class="btn  btn-block  btn-success" >Submit</button>
                                    </form>
                                </div>
                            </div>
';
                            } else {
                                //se o cliete deu erro
                                if (isset($_SESSION['erro'])) {
                                    if ($_SESSION['erro'] == "jah_cadastrado") {

                                        echo'<div class="col-sm-6 col-md-6 col-lg-6 slogan">
                                                <div class="wow fadeInUp" data-wow-duration="2s" data-wow-delay="0.2s">
                                                        <h2>Você já participou da promoção!.</h2>
                                                </div>
                                            </div>';
                                    } elseif ($_SESSION['erro'] == 'acabau_premio') {

                                        echo'<div class="col-sm-6 col-md-6 col-lg-6 slogan">
                                                <div class="wow fadeInUp" data-wow-duration="2s" data-wow-delay="0.2s">
                                                        <h2>Desculpe, a promoção ou nossos premios acabaram.</h2>
                                                </div>
                                            </div>';
                                    }
                                } elseif (isset($_SESSION['premio'])) {
                                    echo'<div class="col-sm-6 col-md-6 col-lg-6 slogan">
                                                <div class="wow fadeInUp" data-wow-duration="2s" data-wow-delay="0.2s">
                                                        <h2>Clique no botão e gire a roleta.</h2>
                                                        <br>
                                        <button type="submit" class="btn  btn-block  btn-success" onclick="trocaImagem()">Girar a roleta!!!</button>
                                                </div>
                                            </div>';
                                }
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </section>

            <section id="callaction" class="home-section paddingtop-99">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="callaction">
                                <div class="row">
                                    <div class="col-md-8">
                                        <div class="wow fadeInUp" data-wow-delay="0.1s">
                                            <div class="cta-text">
                                                <h3>Nós ligamos para você!</h3>
                                                <p> Tem alguma dúvida? Quer contratar um Plano da Vetorial?   </p>
                                            </div>
                                            <div class="row">


                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="wow lightSpeedIn" data-wow-delay="0.1s">
                                            <div class="cta-btn">
                                                <a href="#" class="btn btn-skin btn-lg">Nós ligamos para vocês  </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

        </div>
        <a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>
        <script>
            function completa_endereco() {
                cep = $("#cep").val();
                $.ajax({
                    url: "https://viacep.com.br/ws/" + cep + "/json/",
                    cache: false
                })
                        .done(function (end) {
                            $("#rua").val(end.logradouro);
                            $("#cidade").val(end.localidade)
                            $("#estado").val(end.uf)
                            $("#bairro").val(end.bairro)
                            console.log(end);
                        });
            }
        </script>
        <!-- Modal -->

        <div class="modal fade" id="modal_cadastro" role="dialog">
            <div class="modal-dialog"><!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-body">
                        <h2>Cadastro feito com sucesso!</h2>
                        <p>Seu cadastro foi feito. Lembramos que voc&ecirc; pode indicar quantas pessoas quiser.</p>
                    </div>
                    <div class="modal-footer"><button class="btn btn-default" data-dismiss="modal" type="button">Fechar</button></div>
                </div>
            </div>
        </div>

        <?php
        //coloca o premio na variavel que serve pra roleta
        if (isset($_SESSION['premio'])) {
            echo "<script>"
            . "var sorteado = " . $_SESSION['premio'] . ";"
            . "</script>";
        }
        ?>;
        <script>
            function sleep(milliseconds) {
                var start = new Date().getTime();
                for (var i = 0; i < 1e7; i++) {
                    if ((new Date().getTime() - start) > milliseconds) {
                        break;
                    }
                }
            }

            imagem_atual = 0;
            velocidade = 1025;
            etapa = 0;
            acabou = false;
            premio = "Você ganhou 1 mês gratis!";

            function trocaImagem() {
                if (!acabou) {

                    image_velha = "roleta" + ("00" + imagem_atual).slice(-2);
                    image_nova = "roleta" + ("00" + (imagem_atual + 1)).slice(-2);

                    if (imagem_atual == 12) {
                        image_velha = "roleta" + ("00" + imagem_atual).slice(-2);
                        image_nova = "roleta01";
                        imagem_atual = 0;
                    }

                    $("#" + image_velha).hide(0);
                    $("#" + image_nova).show(0);


                    console.log(image_nova);
                    imagem_atual++;
                    if (etapa == 0) {
                        velocidade = velocidade - 125;
                        if (velocidade < 150) {
                            etapa = 1;
                            contador = 0;
                        }
                    }
                    if (etapa == 1) {
                        contador++;
                        if (contador == 50) {
                            etapa = 2;
                        }
                    }
                    if (etapa == 2) {
                        velocidade = velocidade + 125;
                        if (velocidade > 800) {
                            etapa = 3;
                        }
                    }
                    if (etapa == 3) {
                        if (imagem_atual == sorteado) {
                            acabou = true;
                        }
                    }
                    setTimeout(trocaImagem, velocidade);
                } else {
                    switch (imagem_atual) {
                        case 1:
                            premio = "Você ganhou uma caderneta personalizada da Vetorial!";
                            break;
                        case 2:
                            premio = "Você ganhou 50% de desconto na taxa de instalação!"
                            break;
                        case 3:
                            premio = "Você ganhou um fone de ouvido personalizado da Vetorial!"
                            break;
                        case 4:
                            premio = "Você ganhou 1 mês de internet grátis!"
                            break;
                        case 5:
                            premio = "Você ganhou a taxa de instalação grátis!"
                            break;
                        case 6:
                            premio = "Você ganhou 2 meses de internet grátis!"
                            break;
                        case 7:
                            premio = "Você ganhou 1 mês de internet grátis!"
                            break;
                        case 8:
                            premio = "Você ganhou 50% de desconto na taxa de instalação!"
                            break;
                        case 9:
                            premio = "Você ganhou uma caderneta personalizada da Vetorial!"
                            break;
                        case 10:
                            premio = "Você ganhou um fone de ouvido personalizado da Vetorial!"
                            break;
                        case 11:
                            premio = "Você ganhou 3 meses de internet grátis!"
                            break;
                        case 12:
                            premio = "Você ganhou a taxa de instalação grátis!"
                            break;
                        default:
                            premio = "Você ganhou 1 mês de internet grátis!"
                            break;
                    }

                    alert(premio);
                }
            }
        </script>


        <!-- Core JavaScript Files -->
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery.easing.min.js"></script>
        <script src="js/wow.min.js"></script>
        <script src="js/jquery.scrollTo.js"></script>
        <script src="js/nivo-lightbox.min.js"></script>
        <script src="js/custom.js"></script>

    </body>

</html>

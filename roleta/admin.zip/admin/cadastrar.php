<?php

if (!isset($_SESSION)) {
    session_start();
}

include_once("conexao.php");

$nome_usuario = $_POST['nome'];
$telefone_usuario = $_POST['telefone'];
$email_usuario = $_POST['email'];
$cpf_usuario = $_POST['cpf'];
$cep_usuario = $_POST['cep'];
$cidade_usuario = $_POST['cidade'];
$estado_usuario = $_POST['estado'];
$endereco_usuario = $_POST['rua'];
$bairro_usuario = $_POST['bairro'];

//echo"parou aqui4";

$query = "SELECT * FROM usuarios WHERE cpf = '$cpf_usuario' LIMIT 1";
$resultado = $conn->query($query);

if ($resultado->num_rows > 0) {
    $_SESSION['erro'] = "jah_cadastrado";
    //echo "jah cadastrado";
    header("Location:index.php");
    die();
} else {
    if ($bairro_usuario == 'Cassino') {
        $localidade = 'cassino';
    } elseif ($cidade_usuario == 'Rio Grande') {
        $localidade = 'rio grande';
    } elseif ($cidade_usuario == 'Pelotas') {
        $localidade = 'pelotas';
    } elseif ($cidade_usuario == 'São Jose do Norte') {
        $localidade = 'sjn';
    }
}
//vou v
$sql = "SELECT * FROM premios WHERE localidade = '$localidade' AND quantidade > 0 ";
$result = $conn->query($sql);

$premios = array();

//echo"parou aqui3";
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $premios[] = $row["premio"];
    }
} else {
    $_SESSION['erro'] = "acabau_premio";
    header("Location:index.php");
    die();
}
$indece_premio = rand(0, sizeof($premios) -1);
$roleta = 0;

//echo"parou aqui2";
switch ($premios[$indece_premio]) {
    case "headset":
        $posicoes = array(3, 10);
        $roleta = $posicoes[array_rand($posicoes)];
        break;
    case "caderneta":
        $posicoes = array(1, 9);
        $roleta = $posicoes[array_rand($posicoes)];
        break;
    case "1 mês de internet":
        $posicoes = array(4, 7);
        $roleta = $posicoes[array_rand($posicoes)];
        break;
    case "2 meses de internet":
        $posicoes = array(6);
        $roleta = $posicoes[array_rand($posicoes)];
        break;
    case "3 meses de internet":
        $posicoes = array(11);
        $roleta = $posicoes[array_rand($posicoes)];
        break;
    case "50% taxa de insta":
        $posicoes = array(2, 8);
        $roleta = $posicoes[array_rand($posicoes)];
        break;
    case "taxa de instalação":
        $posicoes = array(5, 12);
        $roleta = $posicoes[array_rand($posicoes)];
        break;
}

//echo"parou aqui1";
$result_usuario = "INSERT INTO usuarios(nome, cpf, email, telefone, cep, endereco, bairro, cidade, estado, premio) VALUES ('$nome_usuario','$cpf_usuario','$email_usuario','$telefone_usuario','$cep_usuario','$endereco_usuario','$bairro_usuario','$cidade_usuario','$estado_usuario','".$premios[$indece_premio]."')";
$resultado_usuario = mysqli_query($conn, $result_usuario);
$sql1 = "UPDATE premios SET quantidade = quantidade -1 WHERE localidade = $localidade && premio = " . $_SESSION['premio'];
$resultado_premios = mysqli_query($conn, $sql1);
$_SESSION['premio'] = $roleta;
header("Location:index.php");
die();

<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Rolega Digital - Vetorial Internet</title>

        <!-- css -->
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <link href="css/nivo-lightbox.css" rel="stylesheet" />
        <link href="css/nivo-lightbox-theme/default/default.css" rel="stylesheet" type="text/css" />
        <link href="css/animate.css" rel="stylesheet" />
        <link href="css/style.css" rel="stylesheet">
        <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
        <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
        <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

        <!-- template skin -->
        <link id="t-colors" href="color/default.css" rel="stylesheet">

        <!-- =======================================================
          Theme Name: Appland
          Theme URL: https://bootstrapmade.com/free-bootstrap-app-landing-page-template/
          Author: BootstrapMade
          Author URL: https://bootstrapmade.com
        ======================================================= -->
    </head>

    <body id="page-top" data-spy="scroll" data-target=".navbar-custom">


        <div id="wrapper">

            <nav class="navbar navbar-custom" role="navigation">
                <div class="container navigation">

                    <div class="navbar-header page-scroll">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                            <i class="fa fa-bars"></i>
                        </button>
                        <a class="navbar-brand" href="index.html">
                            <img src="img/logo.png" alt="" width="150" height="40" />
                        </a>
                    </div>

                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
                        <ul class="nav navbar-nav">
                            <li>
                                <div id="cart"></div>
                            </li>
                            <li class="active"><a href="#intro">Home</a></li>
                            <li><a href="#">Store location <span class="label label-danger">65</span></a> </li>

                        </ul>
                    </div>
                    <!-- /.navbar-collapse -->

                </div>
                <!-- /.container -->
            </nav>

            <section id="content1" class="home-section">

                <div class="container">
                    <div class="row text-center heading">
                        <h3>Lista de Clientes</h3>
                    </div>


                    <div class="row">
                        <div class="col-md-12">
                            <table id="example" class="display" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>CPF</th>
                                        <th>Status</th>
                                        <th>Premio</th>
                                        <th>Data</th>
                                        <th>Ações</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    include_once("../conexao.php");

                                    $result_usuarios = "SELECT * FROM usuarios";
                                    $resultado_usuarios = mysqli_query($conn, $result_usuarios);
                                    while ($row_usuario = mysqli_fetch_assoc($resultado_usuarios)) {
                                        echo"<tr>";
                                        echo "<td>" . $row_usuario['ID'] . "</td>";
                                        echo "<td>" . $row_usuario['nome'] . "</td>";
                                        echo "<td>" . substr($row_usuario['cpf'], 0, 3) . "</td>";
                                        echo "<td>" . $row_usuario['status'] . "</td>";
                                        echo "<td>" . $row_usuario['premio'] . "</td>";
                                        echo "<td>" . $row_usuario['data_giro'] . "</td>";
                                        echo '<td> <button type="button" class="btn btn-success" onclick="seleciona_id_contratou(' . $row_usuario['ID'] . ')" data-toggle="modal" data-target="#modalcontratou">Validação</button>
 </td>';
                                        echo "</tr>";
                                    }
                                    ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>Id</th>
                                        <th>Name</th>
                                        <th>CPF</th>
                                        <th>Status</th>
                                        <th>Premio</th>
                                        <th>Data</th>
                                        <th>Ações</th>

                                    </tr>
                                </tfoot>
                            </table>

                            <script>
                                $(document).ready(function () {
                                    $('#example').DataTable();
                                });
                            </script>
                        </div>
                    </div>
                </div>

            </section>
            <!-- /Section: content -->


            <footer>


                <div class="sub-footer">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-6 col-md-6 col-lg-6">
                                <ul class="social">
                                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                                    <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                                </ul>

                                <div class="wow fadeInLeft" data-wow-delay="0.1s">
                                    <div class="text-left">
                                        <p>&copy;Copyright - Appland. All rights reserved.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-6 col-lg-6">
                                <div class="wow fadeInRight" data-wow-delay="0.1s">
                                    <div class="text-right margintop-30">
                                        <div class="credits">
                                            <!--
                                              All the links in the footer should remain intact.
                                              You can delete the links only if you purchased the pro version.
                                              Licensing information: https://bootstrapmade.com/license/
                                              Purchase the pro version form: https://bootstrapmade.com/buy/?theme=Appland
                                            -->
                                            Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>

        </div>
        <!-- Modal Contratou-->
        <div id="modalcontratou" class="modal fade" role="dialog">
            <div class="modal-dialog">

                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Contratou</h4>
                    </div>
                    <div class="modal-body">
                        <form id="validacao" action="status.php" method="post">
                            <input type="hidden" id="id_contratou" name="id_cliente" value="">
                            <input type="hidden" id="id_botao" name="botao" value="">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Responsável:</label>
                                        <input  type="text" class="form-control" id="nomeresponsavel" name ="nomeresponsavel" id="nomeresponsavel" required>
                                    </div>
                                </div> 
                                
                        </form>
                    </div>
                            </div>
                    <div class="modal-footer">
                        
                        <button type="button" class="btn btn-success" onclick="botao('contratou')">Contratou</button>;
                        <button type="button" class="btn btn-danger" onclick="botao('inviabilidadetec')" >Inviabilidade Tecnico</button>';
                        <button type="button" class="btn btn-warning" onclick="botao('inviavelcani')" >Inviabilidade Cani</button>';
                       
                    </div>
                    
                </div>

            </div>
        </div>


        <script>
            function seleciona_id_contratou(id_cliente) {
                $("#id_contratou").val(id_cliente);
            }
        </script> 
        <script>
            function botao(nome) {
                if($("#nomeresponsavel").val().length > 3){
                    $("#id_botao").val(nome);
                    $("#validacao").submit();
                }else{
                    alert("preencha o mimimim")
                }
            }
        </script>
        <a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>

        <!-- Core JavaScript Files -->
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery.easing.min.js"></script>
        <script src="js/wow.min.js"></script>
        <script src="js/jquery.scrollTo.js"></script>
        <script src="js/nivo-lightbox.min.js"></script>
        <script src="js/custom.js"></script>

    </body>

</html>
